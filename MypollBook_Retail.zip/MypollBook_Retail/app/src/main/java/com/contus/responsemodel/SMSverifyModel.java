package com.contus.responsemodel;

/**
 * Created by user on 9/18/2015.
 */
public class SMSverifyModel {
    //success
    private String success;
    //Message
    private String msg;

    /**
     * Get the success
     * @return success
     */

    public String getSuccess() {
        return success;
    }

    /**
     * Get the message
     * @return msg
     */
    public String getMsg() {
        return msg;
    }


}
