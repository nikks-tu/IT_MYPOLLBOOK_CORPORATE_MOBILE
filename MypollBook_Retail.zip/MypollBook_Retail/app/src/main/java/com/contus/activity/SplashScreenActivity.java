/**
 * SplashScreenActivity.java
 * <p/>
 * Displays the splash screen for milliseconds.
 *
 * @category Contus
 * @package com.contus.activity
 * @version 1.0
 * @author Contus Team <developers@contus.in>
 * @copyright Copyright (C) 2015 Contus. All rights reserved.
 * @license http://www.apache.org/licenses/LICENSE-2.0
 */


package com.contus.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.contus.app.Constants;
import com.contus.residemenu.MenuActivity;
import com.contusfly.MApplication;
import com.contusfly.utils.ContusPreferences;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.google.android.gcm.GCMRegistrar;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;
import com.new_chanages.Rewards_Activty;
import com.polls.polls.BuildConfig;
import com.polls.polls.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import static android.support.v7.widget.StaggeredGridLayoutManager.TAG;

/**
 * Created by user on 6/29/2015.
 */
public class SplashScreenActivity extends Activity implements Constants {
    /**
     * Splash time
     **/
    int splashTimeOut = 1000;
    String deviceId;
    //Contus prefernce
    private ContusPreferences contusPreferences;
    private BroadcastReceiver mRegistrationBroadcastReceiver;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Fresco.initialize(this);
        //Initializing the activity
        context = SplashScreenActivity.this;
        contusPreferences = new ContusPreferences(this);
        //Checking the device
        //GCMRegistrar.checkDevice(this);
        //device id from the mobile
        //String deviceId = GCMRegistrar.getRegistrationId(this);
        //Setting the tevice id in prefernce
        //////////FCM Code///////////////////////////////////
        mRegistrationBroadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                // checking for type intent filter
                if (intent.getAction().equals(Config.REGISTRATION_COMPLETE)) {
                    // gcm successfully registered
                    // now subscribe to `global` topic to receive app wide notifications
                    FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);
                    displayFirebaseRegId();

                } else if (intent.getAction().equals(Config.PUSH_NOTIFICATION)) {
                    // new push notification is received

//                    String message = intent.getStringExtra("message");
//
//                    Toast.makeText(getApplicationContext(), "Push notification: " + message, Toast.LENGTH_LONG).show();
//
//                    txtMessage.setText(message);
                }
            }
        };

        displayFirebaseRegId();

        FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);
        deviceId=FirebaseInstanceId.getInstance().getToken();
        //Toast.makeText(this, FirebaseInstanceId.getInstance().getToken(), Toast.LENGTH_SHORT).show();
        contusPreferences.setDeviceToken(deviceId);
        //Log.d("deviceIdSpl",deviceId);
        //Set is notify false
        contusPreferences.setIsNotify(false);
        //Checking the device
        //GCMRegistrar.checkDevice(this);
        //Geting the registeration id
        //deviceId = GCMRegistrar.getRegistrationId(this);
        //if device id is not empty
        if (deviceId != null && deviceId.isEmpty()) {
            //Registering is using t=sender id
            GCMRegistrar.register(this, SENDER_ID);
        }
        //if device id is not null
        if (deviceId != null && deviceId.length() > 0) {
            //Setting the prefernce
            contusPreferences.setDeviceToken(deviceId);
            //setting in prefernce
            com.contusfly.MApplication.setString(SplashScreenActivity.this, Constants.GCM_REG_ID, deviceId);
        }
        Log.e("deviceId   ", deviceId + "");
        /**Setting the layout full screen**/
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            //Full screen view
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
        /**layoput**/
        setContentView(R.layout.activity_splash);
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {


                validateAppVersion();
                //Getting the boolaean from prefernce


            }
        }, splashTimeOut);

    }
    private void displayFirebaseRegId() {
        SharedPreferences pref = getApplicationContext().getSharedPreferences(Config.SHARED_PREF, 0);
        deviceId = pref.getString("regId", null);

        Log.e(TAG, "Firebase reg id: " + deviceId);

        //if (!TextUtils.isEmpty(regId))
            //txtRegId.setText("Firebase Reg Id: " + regId);
       // else
            //txtRegId.setText("Firebase Reg Id is not received yet!");
    }



    public void validateAppVersion(){
        final int versionName = BuildConfig.VERSION_CODE;
        final HashMap<String, Integer> paramss = new HashMap<>();
        paramss.put("device_id", versionName);
        CustomRequest.makeJsonObjectRequest(SplashScreenActivity.this,Constants.LIVE_BASE_URL+"api/v1/version",new JSONObject(paramss), new VolleyResponseListener() {
            @Override
            public void onError(String message) {
//            dialog.dismiss();
                Log.i("onErrormessage", "message= " +message);
            }

            @Override
            public void onResponse(JSONObject response) {
                Log.i("PCCmessage", "message " + response.toString());
                JSONObject result = response;
                int version_no=0;
                try {
                    Log.i("PCCmessage", "message " + result.getString("msg"));

                    version_no =Integer.parseInt(result.getString("results"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                try {
                    if (versionName<version_no) {
                        context = SplashScreenActivity.this;
                        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                        android.support.v7.app.AlertDialog.Builder alertDialog = new android.support.v7.app.AlertDialog.Builder(SplashScreenActivity.this);
                        final View view = inflater.inflate(R.layout.versionpopup, null);
                        alertDialog.setView(view);
                        final android.support.v7.app.AlertDialog alert = alertDialog.show();
                        TextView updateText=(TextView) view.findViewById(R.id.id_updateText);
                        TextView update = (TextView) view.findViewById(R.id.id_update);
                        TextView cancel = (TextView) view.findViewById(R.id.cancel);
                        updateText.setText(result.getString("msg"));
                        update.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.polls.polls&hl=en" )));

                            }
                        });
                        cancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                if (alert != null && alert.isShowing()) {
                                    alert.dismiss();


                                    if (!MApplication.getBoolean(SplashScreenActivity.this,
                                            FIRST_TIME)) {
                                        //An intent is an abstract description of an operation to be performed. It can be used with startActivity to launch an Activity, broadcastIntent to send it to any interested BroadcastReceiver components, and startService(Intent) or bindService(Intent, ServiceConnection, int)
                                        // to communicate with a background Service.
                                        Intent intent = new Intent(getApplicationContext(),
                                                Welcome.class);
                                        //starting the activity
                                        startActivity(intent);
                                    } else {
                                        ((MApplication) getApplication()).startLoginService(SplashScreenActivity.this);
                                        //An intent is an abstract description of an operation to be performed. It can be used with startActivity to launch an Activity, broadcastIntent to send it to any interested BroadcastReceiver components, and startService(Intent) or bindService(Intent, ServiceConnection, int)
                                        // to communicate with a background Service.
                                        Intent intent = new Intent(getApplicationContext(),
                                                MenuActivity.class);
                                        //starting the activity
                                        startActivity(intent);
                                    }

                                    finish();
                                }
                            }
                        });

                        alert.show();
                        alert.setCancelable(false);
                    }
                    else
                    {
                        if (!MApplication.getBoolean(SplashScreenActivity.this,
                                FIRST_TIME)) {
                            //An intent is an abstract description of an operation to be performed. It can be used with startActivity to launch an Activity, broadcastIntent to send it to any interested BroadcastReceiver components, and startService(Intent) or bindService(Intent, ServiceConnection, int)
                            // to communicate with a background Service.
                            Intent intent = new Intent(getApplicationContext(),
                                    Welcome.class);
                            //starting the activity
                            startActivity(intent);
                        } else {
                            ((MApplication) getApplication()).startLoginService(SplashScreenActivity.this);
                            //An intent is an abstract description of an operation to be performed. It can be used with startActivity to launch an Activity, broadcastIntent to send it to any interested BroadcastReceiver components, and startService(Intent) or bindService(Intent, ServiceConnection, int)
                            // to communicate with a background Service.
                            Intent intent = new Intent(getApplicationContext(),
                                    MenuActivity.class);

                            /*Intent intent = new Intent(getApplicationContext(),
                                    Rewards_Activty.class);*/
                            //starting the activity
                            startActivity(intent);
                        }

                        finish();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });
    }
}
