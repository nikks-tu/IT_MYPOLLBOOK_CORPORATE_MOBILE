package com.contusfly.model;

/**
 * Created by user on 14/11/16.
 */

public class PollUnseenStatusModel {
    private String message;
    private String responsecode;
    public String getResponseMessage() {
        return message;
    }

    public String getResponseCode() {
        return responsecode;
    }
}
